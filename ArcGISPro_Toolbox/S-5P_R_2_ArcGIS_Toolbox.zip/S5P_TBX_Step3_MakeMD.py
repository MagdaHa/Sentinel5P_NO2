#++++++++++++++++++++++++++++++++++++++++++++++
#
#  Make MosaicDataset from R-retrieved Sentinel 5P-data in tiff format
#  at that time, NoData is already expected to be set to 0 in the datasets!
#
# Parameters:
#    [needed]   param 1: a GDB to store the Mosaic in
#    [needed]   param 2: a mosaic dataset name (to create or update)
#    [needed]   param 3: the projection for the MD
#    [needed]   param 4: the folder where to find the S5p tiffs
#    [needed]   param 5: build Multidimensional Info for MD?
#+++++++++++++++++++++++++++++++++++++++++++++++
import os, sys, re
import arcpy
import argparse

#-------------------------
# simple messaging in ArcPy and console
def message(Mstr,Mtype):
    if 'ArcMap' in sys.executable or 'ArcGISPro' in sys.executable:
        if Mtype == "M":
            arcpy.AddMessage(Mstr)
        elif Mtype == "W":
            arcpy.AddWarning(Mstr)
        else:
            arcpy.AddError(Mstr)
    else:
        print (Mtype+": "+Mstr)
#------------------------------
# helper to find unique field values, creates value list
def unique_values(table, field):
    with arcpy.da.SearchCursor(table, [field]) as cursor:
        return sorted({row[0] for row in cursor})
#------------------------------
# helper to define the MultiDim definition string for the potential several variables
def returnVariableString(dim_list):
    prod_subst = ["NO2","SO2","O3","CH4","HCHO","AER_LH","CO","NP_BD3","CLOUD","AER_AI","qa-cloud"]
    prod_desc = ["molecules/cm**-2","DobsonUnit","DobsonUnit","ppm","molecules/cm**-2","hPa","mol/cm**-2","L2__NP_BD3","km","L2__AER_AI","qa-cloud"]
    #prod_desc = ["molecules/cm**-2","molecules/cm**-2","molecules/cm**-2","molecules/cm**-2","molecules/cm**-2","hPa","molecules/cm**-2","molecules/cm**-2","km","L2__AER_AI","qa-cloud"]

    desc = ''
    for i in dim_list:
        substr=i+" '"+i+" S5P TROPOMI"+"' "+prod_desc[prod_subst.index(i)]
        if len(desc) < 1:
            desc = desc+substr
        else:
            desc=desc+';'+substr
    return(desc)
#------------------------------
def main():
    #get and check the arguments
    parser=argparse.ArgumentParser(description='Make Mosaic from S5P Tiffs')
    parser.add_argument('MDWorkspace',metavar='MDWorkspace', help='The MosaicDataset Workspace/GDB')
    parser.add_argument('MDName',metavar='MDName', help='The new MD to create')
    parser.add_argument('MDSRS',metavar='MDSRS', help='The Spatial Reference System to use for the new MD')
    parser.add_argument('S5Ppath',metavar='S5Ppath', help='The path to the (s5P) images to add to the Mosaic')
    parser.add_argument('Multidim',metavar='MDmultidim', help='Build Multidimensional Info for MD?')
    args = parser.parse_args()
##    #just to debug
##    #parser.print_help()
##    #print (args)
##    #print all parsed parameters
##    message('--------------------','M')
##    message('ARGUMENTS PARSED','M')
##    message('--------------------','M')
##    message('Workspace: '+args.MDWorkspace,"M")
##    message('MD-Name: '+args.MDName,"M")
##    message('MD-SRS: '+args.MDSRS,"M")
##    message('Data-Path: '+args.S5Ppath,"M")
##    message('Create MultiDim?: '+args.Multidim,"M")
##    message('--------------------','M')


    #set the workspace to be the GDB
    arcpy.env.workspace = args.MDWorkspace
    #check if MD existed at that point - decicife for future behaviour
    if arcpy.Exists(args.MDName):
        did_exist = True
    else:
        did_exist = False
    #create the MosaicDataset:
    try:
        if did_exist:
            message('Mosaic Dataset exists, Data will be appended','M')
        else:
            arcpy.SetProgressorLabel("Creating Mosaic Dataset ...")
            arcpy.management.CreateMosaicDataset(args.MDWorkspace, args.MDName, args.MDSRS)
            message('Created Mosaic Dataset','M')
    except:
        message('Failed to create MosaicDatset - exit!','E')
        exit(0)
    #add the Time reference field:
    try:
        fld_exists = "no"
        if did_exist:
            #we have to check if the field exists ...
            desc = arcpy.Describe(args.MDName)
            flds=desc.fields
            for fld in flds:
                if fld.name == "StdTime":
                    fld_exists = "yes"
        if fld_exists == "no":
            arcpy.SetProgressorLabel("Adding Time field ...")
            TableName = args.MDName+r'\Footprint'
            arcpy.management.AddField(args.MDName, "StdTime", "DATE", None, None, None, "DateTime", "NULLABLE", "NON_REQUIRED", '')
            message('Added StdTime Field','M')
        else: #field already there
           message('StdTime Field already there','M')
    except:
        message('Failed to Add TimeField - exit!','E')
        exit(1)
    #now add the datasets
    try:
        arcpy.SetProgressorLabel("Add data to Mosaic Dataset ...")
        if did_exist:
            message('Datasets will be appended, duplicates excluded','M')
            arcpy.management.AddRastersToMosaicDataset(args.MDName, "Raster Dataset", args.S5Ppath, "UPDATE_CELL_SIZES", "UPDATE_BOUNDARY", "NO_OVERVIEWS", None, 0, 1500, None, '', "SUBFOLDERS", "EXCLUDE_DUPLICATES", "NO_PYRAMIDS", "CALCULATE_STATISTICS", "NO_THUMBNAILS", '', "NO_FORCE_SPATIAL_REFERENCE", "ESTIMATE_STATISTICS", None, "NO_PIXEL_CACHE", '')

        else:
            message('New MD, all Datasets will be added, duplicates allowed','M')
            arcpy.management.AddRastersToMosaicDataset(args.MDName, "Raster Dataset", args.S5Ppath, "UPDATE_CELL_SIZES", "UPDATE_BOUNDARY", "NO_OVERVIEWS", None, 0, 1500, None, '', "SUBFOLDERS", "ALLOW_DUPLICATES", "NO_PYRAMIDS", "CALCULATE_STATISTICS", "NO_THUMBNAILS", '', "NO_FORCE_SPATIAL_REFERENCE", "ESTIMATE_STATISTICS", None, "NO_PIXEL_CACHE", '')
        message('Datasets have been added','M')
    except:
        message('Failed to add rasters to MosaicDatset - exit!','E')
        exit(2)

    #calculate the STDTime Field value and assign the Group to the Substance found in the filename
    try:
        arcpy.SetProgressorLabel("Calculate Field Values ...")
        arcpy.management.CalculateField(args.MDName, "StdTime", "datetime.datetime.strptime(!Name![:15], '%Y%m%dT%H%M%S')", "PYTHON3", '', "TEXT")
        #arcpy.management.CalculateField(args.MDName, "GroupName", "'" + S5PSubstance + "'", "PYTHON3", '', "TEXT")
        arcpy.management.CalculateField(args.MDName, "GroupName", "getSubstance(!Name!)", "PYTHON3", """def getSubstance(FileName):\n    import re\n    return(re.sub('_+','_',FileName).split('_')[2])""","TEXT")

        #if dataset already exists, the variable and dimension fields need to be updated, too if existing
        if did_exist:
            Dim_exists = "no"
            desc = arcpy.Describe(args.MDName)
            flds=desc.fields
            for fld in flds:
                if fld.name == "Dimensions":
                    #as this field is there, we need to fill the records, so the update of MultiDim will work
                    arcpy.management.CalculateField(args.MDName, "Variable", "getSubstance(!Name!)", "PYTHON3", """def getSubstance(FileName):\n    import re\n    return(re.sub('_+','_',FileName).split('_')[2])""","TEXT")
                    #arcpy.management.CalculateField(args.MDName, "Variable", "'" + S5PSubstance + "'", "PYTHON3", '', "TEXT")
                    arcpy.management.CalculateField(args.MDName, "Dimensions", "'StdTime'", "PYTHON3", '', "TEXT")
        message('Fields calculated','M')
    except:
        message('Failed to properly calculate fields - please check!','W')
    #now apply the modified defaults
    try:
        if did_exist:
            message ('MD exists ... skip MD Properties','M')
        else:
            arcpy.SetProgressorLabel("Setting Mosaic Dataset Properties ...")
            arcpy.management.SetMosaicDatasetProperties(args.MDName, 4100, 15000, "JPEG;LZ77;LERC", "LZ77", 75, 0.01, "NEAREST", "NOT_CLIP", "FOOTPRINTS_MAY_CONTAIN_NODATA", "CLIP", "NOT_APPLY", None, "NONE", "Center;None;NorthWest;LockRaster;ByAttribute", "ByAttribute", "StdTime", '1990/01/01 00:00:00', "ASCENDING", "FIRST", 10, 600, 300, 20, 0.8, "0 0", "Basic", "Name;MinPS;MaxPS;LowPS;HighPS;Tag;GroupName;ProductName;CenterX;CenterY;ZOrder;StdTime", "ENABLED", "StdTime", "", "YYYY-MM-DD hh:mm:ss", None, 0, 1000, "SCIENTIFIC")
            #need the next line to set NoData on the MosaicDataset level
            arcpy.management.SetRasterProperties(args.MDName, "SCIENTIFIC", None, None, "1 0.0", None)
            message('MosaicDataset Properties set','M')
    except:
        message('Failed to set Properties for MosaicDatset - keep going!','W')

    # now define NoData, rebuild the boundary and calculate proper statistics
    try:
        #NoData taken out for now
##        if did_exist:
##            message ('MD exists ... skip NoData','M')
##        else:
##            arcpy.SetProgressorLabel("Define NoData ...")
##            arcpy.management.DefineMosaicDatasetNoData(args.MDName, 1, None, "BAND_1 0.0 1.0", '', "NO_COMPOSITE_NODATA")
##            message('NoData defined','M')
        arcpy.SetProgressorLabel("Building Boundary ...")
        arcpy.management.BuildBoundary(args.MDName, '', "OVERWRITE", "NONE")
        message('Boundary built','M')
        arcpy.SetProgressorLabel("Calculating Statistics ...")
        arcpy.management.CalculateStatistics(args.MDName, 4, 4, [0], "OVERWRITE", '')
        message('Statistics calculated','M')
    except:
        message('Failed to properly calculate NoData, built Boundary or Calculate statistics - please check!','W')

    #only if opted in for - create the multidim info for the MD
    if args.Multidim == 'true':
        #first, get a list of dimensions currently in the table
        dim_list = unique_values(args.MDName,'GroupName') #this should work, even if MultiDim was never built
        #now, from that list, generate a string for the multidim gp tool
        desc = returnVariableString(dim_list)
        #desc = "NO2 'Vert col no2' xxx;SO2 'Vert col so2' xxx2"
        message('Desc: '+desc,'M')
        try:
            if did_exist:
                #now field variable is already there and filled
                arcpy.SetProgressorLabel("Updating Multidimensional Information ...")
                #set the proper description for all substances - Dimension is Time, Variables may vary - are in Variable-field
                arcpy.md.BuildMultidimensionalInfo(args.MDName, "Variable", "StdTime 'Date and Time' DateTime", desc)
                message('Multidim-Info updated','M')
            else:
                arcpy.SetProgressorLabel("Building Multidimensional Information ...")
                #set the proper description for all substances - Dimension is Time, Variables may vary - are still in GroupName Field
                arcpy.md.BuildMultidimensionalInfo(args.MDName, "GroupName", "StdTime 'Date and Time' DateTime", desc)
                message('Multidim-Info added','M')

        except:
            message('Failed to add MultiDim Info - please check!','W')


if __name__ == '__main__':
    main()
    message("finished",'M')