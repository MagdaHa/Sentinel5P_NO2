# Toolbox-integration r-Tool to convert nc files to GTiff using r
# currently hardwired quite a bit on products to analyze!!!
# adapted from original r-Script by Magdalena Halbgewachs, m.halbgewachs@esri.de
# optional contact: r.schuepferling@esri.de

tool_exec <- function(in_params, out_params)
{

  #####################################################################################################
  ### Check/Load Required Packages
  #####################################################################################################
  arc.progress_label("Loading packages...")
  arc.progress_pos(0)

##  if(!requireNamespace("raster", quietly = TRUE))
##    install.packages("raster", quiet = TRUE)
##  if(!requireNamespace("rgeos", quietly = TRUE))
##    install.packages("rgeos", quiet = TRUE)
##  if(!requireNamespace("sf", quietly = TRUE))
##    install.packages("sf", quiet = TRUE)
##  if(!requireNamespace("sp", quietly = TRUE))
##    install.packages("sp", quiet = TRUE)
##  if(!requireNamespace("arcgisbinding", quietly = TRUE))
##    install.packages("arcgisbinding", repos="http://r-arcgis.github.io/r-bridge", type="win.binary", quiet=TRUE)
##
### these require devtools if not already there
##  if(!requireNamespace("devtools", quietly = TRUE))
##    install.packages("devtools", quiet = TRUE)
##  require (devtools)
##  if(!requireNamespace("getSpatialData", quietly = TRUE))
##    devtools::install_github("16EAGLE/getSpatialData", force=TRUE)
##   if(!requireNamespace("S5Processor", quietly = TRUE))
##     devtools::install_github("MBalthasar/S5Processor", force=TRUE)


  require(sp)
  require(sf)
  require(arcgisbinding)
  require(getSpatialData)
  require(S5Processor) #sp5_process
  require(rgdal)    # several, like showP4
  require(raster)   # shapefile, and others
  require(rgeos)    #the gbuffer




  #####################################################################################################
  ### Helper functions
  #####################################################################################################

#--------------------------------------------------------------------------------------------------------------------------
#data frame and function to define naming/product type for S5P processing
#--------------------------------------------------------------------------------------------------------------------------

return_S5P <- function(filename){
  S5P_data <- data.frame(
  prod_S5Pcode = c(6,6,6,6,6,6,6,6,6,6), #prod-code for available products is always 6, so hardcoded further below
  prod_name = c("Nitrogene Dioxide","Sulphur Dioxide","Ozone","Methane","Formaldehyde","Aerosol Layer Height","Carbon Monoxide","Cloud SUOMI","Cloud","Aerosol Index"),
  prod_type = c("L2__NO2___","L2__SO2___","L2__O3____","L2__CH4___","L2__HCHO__","L2__AER_LH","L2__CO____","L2__NP_BD3","L2__CLOUD_","L2__AER_AI")
  )
  fname <- basename(filename)
  for (row in 1:nrow(S5P_data)){
    the_type <- S5P_data[row,"prod_type"]
    if (grepl(the_type,fname)){return (the_type)}
  }
}
#--------------------------------------------------------------------------------------------------------------------------
#function to just return the wanted name component
#--------------------------------------------------------------------------------------------------------------------------
split_path <- function(path, mustWork = FALSE) {
  output <- c(strsplit(dirname(normalizePath(path,mustWork = mustWork)),
                       "/|\\\\")[[1]], basename(path))
  output <- rev(output)[1] #just the file name is first element of output
  output <- unlist(strsplit(output,'\\.'))[1] #get rid of extension
  #only take last part as unique and having date in it
  #next line will extract the processing date, not good as reference for sensing time, can be days later
  #output <- gsub("^.*_", "", output)
  #next line will extract the BEGINN of the swath-date - this is currently used
  output <- substr(output,21,35)
  # next line will extract the END of the swath-date
  #output <- substr(output,37,51)
  ##------------------------------
  ##this would be the way to use the middle of both. Diasadvantage: You will not find the original NetCDF file using this ;(
  #startdate <- srtptime(substr(output,21,35),format="%Y%m%dT%H%M%S")
  #enddate <- srtptime(substr(output,37,51),format="%Y%m%dT%H%M%S")
  #middate <- startdate+((enddate-startdate)/2)
  #output <- as.character(middate,format="%Y%m%dT%H%M%S")
  ## ------------------------------
  return(output)
}

#--------------------------------------------------------------------------------------------------------------------------
#function to convert nc to tiff - also using the settings for clip and transform
#--------------------------------------------------------------------------------------------------------------------------
nc2gtiff <- function(index, attempt, progress, step, outres) {
  #scaled and resolution set
  progress_string <- paste("Processing file ", index, "of ", the_count, "named ", file_list[index])
  arc.progress_label(progress_string)
  S5P_scaled <- S5P_process(input = file_list[index], my_res = outres,
                               product = 6, extent_only = FALSE, apply_scale_factor = TRUE, interpol_method='ngb') #product 6 = the total column used here - check S5P doku!!)
  #also get clouds
  S5P_cloud <- S5P_process(input = file_list[index], my_res = outres, product = 5, extent_only = FALSE, interpol_method='bilinear')  #product = 5 (qa_value; =< 0.5 is cloud) #can also interpol 'ngb'
  #compile final tiff incl. cloud_mask
  S5P_final <- S5P_scaled
  #S5P_final[S5P_cloud <= 0.5] <- -3.4e+38 # qa-value <= 0.5 filters clouds, if using 0.75 youd also filter snow ...
  S5P_final[S5P_cloud <= 0.5] <- NA

  #is it to be transformed/projected? [input param]
  if (do_proj == 'TRUE'){
  print ("now transforming crs ...")
  S5P_final <- projectRaster(S5P_final, crs=use_proj)
  #S5P_final <- spTransform(S5P_final, use_proj)
  }

  #is it to be clipped to shape?
  if (do_clip == 'TRUE'){
  print ("now clipping ...")
  #in that case, we need the current crs of the dataset
  cur_crs <- crs(S5P_final)
  #print (paste("Cur CRS : ",cur_crs))
  #print (paste("Clip CRS : ",clip_crs))
  #if this cur_crs does not match the crs of the clip geometry, we need to adust this
  #this CAN happen if no projection was specified
  if (toString(cur_crs) != toString(clip_crs)) {
  clip_aoi <- spTransform(clip_aoi, cur_crs)
  }
  S5P_final <- crop(S5P_final, clip_aoi)
  S5P_final <- mask(S5P_final, clip_aoi)
  }

  #write out
  print (paste("now saving with out_res ",out_res,"m ..."))
  #first, get new name element - just START DATE of swath as part (21-35) of former file_name
  fname <- split_path(file_list[index])
  #second, get the product_type of this file and use as part of filename
  ftype <- return_S5P(file_list[index])
  #now write to tiff
  writeRaster(S5P_final, filename = paste0(out_path,"/", fname,"_",ftype,"_",toString(out_res), ".tif"), format="GTiff",overwrite=T)
  print("Success\n")
  remove('S5P_scaled','S5P_cloud','S5P_final','clip_aoi','cur_crs','fname','ftype')
  progress <- progress+step
  arc.progress_pos(progress)
  return(c(1,progress))
}
#--------------------------------------------------------------------------------------------------------------------------



  #####################################################################################################
  ### Define input/output parameters
  #####################################################################################################
  arc.progress_label("Process Parameters...")
  arc.progress_pos(0)

  in_path <- gsub("\\\\", "/", in_params[[1]])
  #print (in_path)
  out_path <- gsub("\\\\", "/", in_params[[2]])
  #print out_path
  out_res <- as.integer(in_params[[8]])
  new_only <- in_params[[9]] #flag to only convert files that are not in target folder already

# now the optional ones - projection first
  do_proj <- in_params[[3]] #change projection
  #print (do_proj)
  if (do_proj == 'TRUE'){
  use_proj <- in_params[[4]]
  #print (use_proj)
  #create crs (proj.4) from WKT - here using rgdal showP4 - also possible with arc.fromWKToP4
  use_proj <- showP4(use_proj)
  #print (use_proj)
  }

# now the optional ones - now clipping (with/without buffering)
  do_clip <- in_params[[5]]
  if (do_clip == 'TRUE'){
  #print (paste("Do clip is true",do_clip))
  use_clip <- gsub("\\\\", "/", in_params[[6]])
  #print (paste("Use clip",use_clip))
  buf_dist <- as.integer(in_params[[7]])
  if (buf_dist > 0){
  do_buf <- 'TRUE'
  } else {
  do_buf <- 'FALSE'
  }
   #define the clip_aoi object
   clip_aoi <- raster::shapefile(use_clip, warnPRJ=FALSE)
   clip_crs <- crs(clip_aoi)
   #if a transformation was defined, apply it to the clip extent
   if (do_proj == 'TRUE'){
   print ("transforming clip_aoi ...")
   clip_aoi <- spTransform(clip_aoi, use_proj)
   }
   #if buffer_distance greater 0 , do buffer the aoi with the given distance (rgeos gBuffer)
   if (do_buf == 'TRUE'){
   print (paste("Buffering clip_aoi with",toString(buf_dist),"m ..."))
   clip_aoi <- gBuffer(clip_aoi, byid=FALSE, quadsegs=3, width=buf_dist)
   #now clip_aoi is ready for use in nc4togtiff function
   }
  }

#--------------------------------------------------------------------------------------------------------------------------
# check on output directory for conversion
if (dir.exists(out_path)){
  set_archive(out_path) #this will empty an existing directory!
  }
  else{
    dir.create(out_path)
    set_archive(out_path) #this will empty an existing directory!
  }
  #print (out_path)
#--------------------------------------------------------------------------------------------------------------------------


  #####################################################################################################
  ### This is the real run
  #####################################################################################################

#--------------------------------------------------------------------------------------------------------------------------
# Cycle through nc files and convert to GTIFF
# Get params for progress indicator:
# first, create the file_list with full paths:
file_list <- list.files(path=in_path, pattern="*.nc", full.names=TRUE, recursive=FALSE)
# ------
# this block will only happen if "new_only was selected ... the file_list will be checked against existing files in folder
# and if already existing, the element will be removed from the file list
if (new_only == 'TRUE'){
  nc_count <- length(file_list) #length of nc file list
  #print (paste("NC-list ",toString(nc_count),"existing records"))
  tif_list <- list.files(path=out_path, pattern="*.tif", full.names=FALSE, recursive=FALSE)
  tif_count = length(tif_list) #length of tif file list
  #print (paste("Out-list ",toString(tif_count),"existing records"))
  ##now create a list of the existing tiffs
  tif_name_list <- c()
  for (j in 1:tif_count){
  tif_name_list <- c(tif_name_list,substr(tif_list[j],1,15))
  }
  #print (tif_name_list)
  clone_list <- file_list #make a copy to work on
  remove_index_list <- c() #empty string list for ids to remove
  for (i in 1:nc_count){
    nc_name <- split_path(file_list[i]) #this is the timestamp of the nc file used as naming convention for tif file (substr(
    #print (paste('nc:',nc_name))
    #now check if in tif_name_list - if yes, remove from list to be processed
    if (is.element(nc_name,tif_name_list)) remove_index_list<- c(remove_index_list,i) #is nc_file already processed?

  }
    #now we should have a list of elements to remove from the filelist to convert - so lets do
    #print (remove_index_list)
    clone_list <- file_list[-c(remove_index_list)]
    #and re-assign to file_list
    file_list <- clone_list
    print (paste('Of a total of ',toString(nc_count),' nc files,',toString(length(remove_index_list)),' have already been processed to tif. ',toString(length(file_list)),' to be processed'))
}
# now count the (remaining) list (again)
the_count <- length(file_list)
print (paste("Number of (remaining) files is ", the_count))
#now set step and initialize progress
step <- 100.0/the_count
progress <- 0
#--------------------------------------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------------------------------------
# loop that messages, counts, sets progress indicator
for (i in 1:the_count)
{
success <- NULL
attempt <- 0
while(is.null(success) && attempt <= 2){      #only one attempt - but this way messaging if error and continues to next file
  attempt <- attempt+1
  try(
    ret <- nc2gtiff(index=i, attempt=attempt, progress=progress, step=step, outres=out_res)
    )
    success <- ret[1]
    progress <- ret[2]
}
}
#--------------------------------------------------------------------------------------------------------------------------
}
