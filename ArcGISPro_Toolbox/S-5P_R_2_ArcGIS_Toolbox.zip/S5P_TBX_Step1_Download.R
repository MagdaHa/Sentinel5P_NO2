# Toolbox-integration r-Tool to download and process Sentinel-5P data
# currently supporting several substances, but tested only with Nitrogen Dioxide
# adapted from original r-Script by Magdalena Halbgewachs, m.halbgewachs@esri.de
# optional contact: r.schuepferling@esri.de

tool_exec <- function(in_params, out_params)
{

  #####################################################################################################
  ### Check/Load Required Packages
  #####################################################################################################
  arc.progress_label("Loading packages...")
  arc.progress_pos(0)

##  if(!requireNamespace("cat", quietly = TRUE))
##    install.packages("cat", quiet = TRUE)
##  if(!requireNamespace("raster", quietly = TRUE))
##    install.packages("raster", quiet = TRUE)
##  if(!requireNamespace("rgdal", quietly = TRUE))
##    install.packages("rgdal", quiet = TRUE)
##  if(!requireNamespace("devtools", quietly = TRUE))
##    install.packages("devtools", quiet = TRUE)
##  require(devtools)
##  if(!requireNamespace("getSpatialData", quietly = TRUE))
##    devtools::install_github("16EAGLE/getSpatialData", force=TRUE)
##  if(!requireNamespace("sf", quietly = TRUE))
##    install.packages("sf", quiet = TRUE)
##  if(!requireNamespace("sp", quietly = TRUE))
##    install.packages("sp", quiet = TRUE)
##  if(!requireNamespace("arcgisbinding", quietly = TRUE))
##    install.packages("arcgisbinding", repos="http://r-arcgis.github.io/r-bridge", type="win.binary", quiet=TRUE)

  rgdal_show_exportToProj4_warnings="none"
  require(rgdal)
  require(cat)
  require(raster)
  require(getSpatialData)
  require(sp)
  require(sf)
  require(arcgisbinding)



  #####################################################################################################
  ### Define input/output parameters
  #####################################################################################################
  arc.progress_label("Process Parameters...")
  arc.progress_pos(1)

#library(getSpatialData)
#library(raster)
#library(sf)
#library(sp)

#define a dataframe for the Sentinel 5p products relevant, as named and used in S5P package (used later)
S5P_data <- data.frame(
prod_S5Pcode = c(6,6,6,6,6,6,6,6,6,6),
prod_name = c("Nitrogen Dioxide","Sulphur Dioxide","Ozone","Methane","Formaldehyde","Aerosol Layer Height","Carbon Monoxide","Cloud SUOMI","Cloud","UV Aerosol Index"),
prod_type = c("L2__NO2___","L2__SO2___","L2__O3____","L2__CH4___","L2__HCHO__","L2__AER_LH","L2__CO____","L2__NP_BD3","L2__CLOUD_","L2__AER_AI")
)

  shape_path <- gsub("\\\\", "/", in_params[[1]])
  aoi_data <- as(st_geometry(st_read(shape_path)),"Spatial")
  arc.progress_pos(3)
  start_time <- toString(as.Date(in_params[[2]], format = "%m/%d/%y"))
  end_time <- toString(as.Date(in_params[[3]], format = "%m/%d/%y"))
  time_range <- c(start_time, end_time)
  products <- in_params[[4]]
  sub_product <- in_params[[5]]
  #this is - if needed - how to query the s5P product code and type to use (for naming)
  #sub_product_code <- S5P_data[which(S5P_data$prod_name == sub_product),names(S5P_data) %in% c("prod_S5Pcode")]
  #sub_product_type <- S5P_data[which(S5P_data$prod_name == sub_product),names(S5P_data) %in% c("prod_type")]

  uname <- in_params[[6]]
  upass <- in_params[[7]] # does not work with hidden or encrypted string :(
  out_path <- gsub("\\\\", "/", out_params[[1]])
  #filearchive <- out_path

#--------------------------------------------------------------------------------------------------------------------------
# check on output directory for the download
if (dir.exists(out_path)){
  set_archive(out_path) #variable used by getSpatialData as default!
  }
  else{
    dir.create(out_path)
    set_archive(out_path) #variable used by getSpatialData as default!
  }
  #print (out_path)
#--------------------------------------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------------------------------------
#Setting an area of interest by using the preloaded shape file - not needed when using getSentinel_records() below
#set_aoi(aoi_data)
#optional anchoring AOI
#view_aoi()
#--------------------------------------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------------------------------------
# Log in into your Copernicus Hub account
  arc.progress_label("Login to Copernicus Hub...")
  arc.progress_pos(5)
  xx <- login_CopHub(username = uname, password = upass)
  #print (xx)
#--------------------------------------------------------------------------------------------------------------------------

###--------------------------------------------------------------------------------------------------------------------------
### specify an output directory for downloaded scenes
##set_archive(out_path)
###--------------------------------------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------------------------------------
# Querying the Sentinel Hub
  arc.progress_label("Query Copernicus Hub by AOI and Dates...")
  arc.progress_pos(6)
records <- getSentinel_records(time_range=time_range,products=products,aoi=aoi_data)
print (sub_product)
print (records)
# list colnames for check if needed
# colnames(records)
#gd filter by variable clear text attribute instead
arc.progress_label("Filter Datasets...")
arc.progress_pos(8)
records_filtered <- records[which(records$producttypedescription == sub_product),] #filtered by selected subproduct
#--------------------------------------------------------------------------------------------------------------------------
#For Debugging in R View records tables here if wanted
#View(records)
#View(records_filtered)
# For ArcGIS GP Run just list record-count
fcount <- nrow(records)
rcount <- nrow(records_filtered)
cat(sprintf('Number of files to download: %i filtered from full date list count %i\n\n', rcount, fcount))
arc.progress_pos(10)
#--------------------------------------------------------------------------------------------------------------------------
# Actually downlod the list of scenes one by one for use of ArcGIS progress indicator
# Get params for progress indicator:
step <- 90/rcount
progress <- 10

#function to just download one dataset from selection by index
onedataset <- function(index, attempt, progress,step,target) {
  progress_string <- paste("Downloading record ", index, "of ", rcount)
  arc.progress_label(progress_string)
  ds_id <- records_filtered[c(index),]$record_id[1]
  cat(sprintf("Attempt %i for dataset %s: ", attempt, ds_id))
  #this version creates new paths - dont want that
  #getSentinel_data(records = records_filtered[c(index),],verbose=FALSE,md5_check=FALSE)
  #this version uses given path - better
  getSentinel_data(records = records_filtered[c(index),],dir_out=target,verbose=FALSE,md5_check=FALSE)
  cat(sprintf("Success\n"))
  progress <- progress+step
  arc.progress_pos(progress)
  return(c(1,progress))
}

# loop that retries if fail, counts, sets progress indicator
if (rcount > 0){
for (i in 1:rcount)
{
success <- NULL
attempt <- 0
while(is.null(success) && attempt <= 10){      #tries to download data 10 times before it stops
  attempt <- attempt+1
  try(
    ret <- onedataset(index=i, attempt=attempt, progress=progress, step=step, target=out_path)
    )
    success <- ret[1]
    progress <- ret[2]
}
}
} else{
cat(sprintf('As there are %i files to download, operation ends here\n\n', rcount))
}
#--------------------------------------------------------------------------------------------------------------------------
}
